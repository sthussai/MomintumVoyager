

<div  id="snackbar"><?php echo e($slot); ?> </div>
     
     <script>
     function myFunction() {
  // Get the snackbar DIV
  var x = document.getElementById("snackbar");

  // Add the "show" class to DIV
  x.className = "show";

  // After 3 seconds, remove the show class from DIV
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
} 
myFunction();
     </script><?php /**PATH C:\xampp\htdocs\testvoyager\resources\views/components/alert.blade.php ENDPATH**/ ?>