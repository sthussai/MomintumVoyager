<?php $__env->startSection('title','Payments'); ?>

<?php $__env->startSection('content'); ?>



<div class="w3-center    w3-panel w3-card">

<!-- START Payment Nav Bar -->
                    <a class="w3-btn" href="/payment">Home</a>           
                    <a class="w3-btn " href="/addpaymentmethod">Add Payment Method</a>
                    <a class="w3-btn " href="/editbillinginfo">Update Billing Information</a>


                </div>
<!-- END Payment Nav Bar -->    

    </div>            

<?php echo $__env->yieldContent('content1'); ?>





 <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.momintum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testvoyager\resources\views/payments/layout.blade.php ENDPATH**/ ?>