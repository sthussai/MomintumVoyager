@extends("payments.layout")



@section('content1')



    <div class="w3-content w3-center w3-panel w3-card">
      <h1>Payment Cancelled</h1>



      <a href="/mprofile" class="w3-card  w3-block w3-hover-shadow w3-margin-bottom">
      <div style="border: solid 2px darkgrey" class=' w3-content w3-padding-16 w3-display-container'>
        Go back to my profile       
        
      </div>
      </a>

                             

    </div>

@endsection