@extends("layout")

@section('title','Welcome')

@section('content')
<div class="content">
    <div class="title m-b-md">
      <h1>Home Page </h1>
    </div>
    <h4>

    </h4>
@endsection