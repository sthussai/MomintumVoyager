@extends("layout")

@section('content')

<div>
	<div>
<h1>About us

</h1></div>

@endsection
